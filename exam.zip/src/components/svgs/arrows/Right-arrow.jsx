function RightArrow ()
{
  return(
    <svg width="28" height="28" fill="none" xmlns="http://www.w3.org/2000/svg"><path opacity=".1" d="M14 28c7.732 0 14-6.268 14-14S21.732 0 14 0 0 6.268 0 14s6.268 14 14 14z" fill="#fff"/><path opacity=".4" fill-rule="evenodd" clip-rule="evenodd" d="M11.998 8.666l-.534.54a.925.925 0 00-.264.653c0 .254.088.47.264.647L14.928 14l-3.464 3.494a.885.885 0 00-.264.647c0 .249.088.467.264.654l.534.532c.18.182.397.273.65.273.256 0 .47-.091.64-.273l4.641-4.68A.858.858 0 0018.2 14a.896.896 0 00-.27-.654l-4.641-4.68a.87.87 0 00-.642-.266.91.91 0 00-.649.266z" fill="#fff"/></svg>
  )
}

export default RightArrow