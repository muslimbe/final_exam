function SearchIcon () {
  return (
    <svg width="19" height="19" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17.9 16.486l-3.58-3.58a8 8 0 10-1.415 1.413l3.58 3.58a1 1 0 101.416-1.413zM13.198 11A6 6 0 112.804 5a6 6 0 0110.393 6z" fill="#fff"/></svg>
  )
}

export default SearchIcon